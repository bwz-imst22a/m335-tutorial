<template>
  <h1>{{ title }}</h1>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const title = ref('Tic-Tac-Toe');
</script>

<style scoped>
</style>