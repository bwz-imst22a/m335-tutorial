import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'bwzRappiIonicApp',
  webDir: 'dist'
};

export default config;
